#' A sum function
#'
#' This function takes a number x and adds 8 to it
#' @param x
#' @keywords x
#' @export
#' @examples


sumfunction <- function(x) {
  x = x + 8
}
